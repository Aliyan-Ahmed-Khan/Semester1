﻿using System;
using System.Windows.Forms;

namespace CPLab_Project
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form3")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 button2 = new Form4();
            button2.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form5 button3 = new Form5();
            button3.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Confirm Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form2 button4 = new Form2();
                button4.Show();
                this.Hide();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 button1 = new Form2();
            button1.Show();
            this.Hide();
        }
    }
}