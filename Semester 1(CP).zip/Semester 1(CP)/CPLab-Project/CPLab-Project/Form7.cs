﻿using System;
using System.Windows.Forms;

namespace CPLab_Project
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form7")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://unlimitedmods.com/it-starts-with-us-colleen-hoover-epub/");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.pdfdrive.com/shatter-me-complete-collection-shatter-me-destroy-me-unravel-me-fracture-me-ignite-me-e200131919.html");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.readingsanctuary.com/ugly-love-pdf/");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://fb2bookfree.com/fiction/5110-the-seven-husbands-of-evelyn-hugo.html");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://d-pdf.com/book/4566/read");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.opportunitiesforyouth.org/wp-content/uploads/2021/04/Atomic_Habits_by_James_Clear-1.pdf");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to logout?", "Logout Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Form6 button8 = new Form6();
                button8.Show();
                this.Hide();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form8 button9 = new Form8();
            button9.Show();
            this.Hide();
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }
    }
}