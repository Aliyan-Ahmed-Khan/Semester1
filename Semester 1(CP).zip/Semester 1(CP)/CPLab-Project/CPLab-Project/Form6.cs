﻿using System;
using System.Windows.Forms;

namespace CPLab_Project
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form6")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form6")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string acc1 = "Aliyan";
            string acc2 = "Zara";
            string acc3 = "Hajra";
            string acc4 = "Humna";
            string acc5 = "Hira";
            string acc6 = "Hamza";

            string pass1 = "password1";
            string pass2 = "password2";
            string pass3 = "password3";
            string pass4 = "password4";
            string pass5 = "password5";
            string pass6 = "password6";

            if (textBox1.Text == acc1 && textBox2.Text == pass1)
            {
                Form7 button2 = new Form7();
                button2.Show();
                this.Hide();
            }
            else if (textBox1.Text == acc2 && textBox2.Text == pass2)
            {
                Form7 button2 = new Form7();
                button2.Show();
                this.Hide();
            }
            else if (textBox1.Text == acc3 && textBox2.Text == pass3)
            {
                Form7 button2 = new Form7();
                button2.Show();
                this.Hide();
            }
            else if (textBox1.Text == acc4 && textBox2.Text == pass4)
            {
                Form7 button2 = new Form7();
                button2.Show();
                this.Hide();
            }
            else if (textBox1.Text == acc5 && textBox2.Text == pass5)
            {
                Form7 button2 = new Form7();
                button2.Show();
                this.Hide();
            }
            else if (textBox1.Text == acc6 && textBox2.Text == pass6)
            {
                Form7 button2 = new Form7();
                button2.Show();
                this.Hide();
            }
            else if (MessageBox.Show("Invalid Credentials", "Warning Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 button3 = new Form1();
            button3.Show();
            this.Hide();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}