﻿using System;
using System.Windows.Forms;

namespace CPLab_Project
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string id = "admin";
            string pass = "incorrect";
            if (textBox1.Text == id && textBox2.Text == pass)
            {
                Form3 button2 = new Form3();
                button2.Show();
                this.Hide();
            }
            else if (MessageBox.Show(" Invalid Credentials ", "Warning Message", MessageBoxButtons.OK, MessageBoxIcon.Exclamation) == DialogResult.OK)
            {
                textBox1.Clear();
                textBox2.Clear();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form2")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 button3 = new Form1();
            button3.Show();
            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            time.Text = DateTime.Now.ToLongTimeString();
            timer1.Start();
        }
    }
}