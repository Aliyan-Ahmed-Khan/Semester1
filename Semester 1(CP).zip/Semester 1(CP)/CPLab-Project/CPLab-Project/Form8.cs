﻿using System;
using System.IO;
using System.Windows.Forms;

namespace CPLab_Project
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form8")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form7 button3 = new Form7();
            button3.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var path = @"D:\Suggestions.txt";
            using (FileStream file = new FileStream(path, FileMode.Append, FileAccess.Write))
            {
                using (StreamWriter write = new StreamWriter(file))
                {
                    write.WriteLine("Book Name: " + textBox1.Text);
                    write.WriteLine("Author Name: " + textBox2.Text);
                    write.WriteLine("Genre: " + textBox3.Text);
                    write.WriteLine();
                }
            }
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            if (MessageBox.Show("Thank you for your suggestion, our team will work on that.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Asterisk) == DialogResult.OK)
            {
                Form7 button1 = new Form7();
                button1.Show();
                this.Hide();
            }
        }
    }
}