﻿using System;
using System.IO;
using System.Windows.Forms;

namespace CPLab_Project
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = Application.OpenForms.Count - 1; i >= 0; i--)
            {
                if (Application.OpenForms[i].Name != "Form5")
                    Application.OpenForms[i].Close();
            }
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 button3 = new Form3();
            button3.Show();
            this.Hide();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            string path = @"D:\StudentDetails.txt";
            using (FileStream file = new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader reader = new StreamReader(file))
                {
                    string task = reader.ReadToEnd();
                    richTextBox1.Text = Convert.ToString(task);
                }
            }
        }
    }
}